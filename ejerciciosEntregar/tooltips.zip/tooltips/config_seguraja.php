<?php
// Datos de conexión a la base de datos
$db_host = "localhost";
$db_nombre = "seguraja_general";
$db_usuario = "seguraja";
$db_contraseña = "s\$Eguraja_#8";
$db_charset = "utf8";
?>