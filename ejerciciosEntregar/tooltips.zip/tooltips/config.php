<?php // Datos de conexión a la base de datos
$db_host = "localhost";
$db_nombre = "cuerpo";
$db_usuario = "root";
$db_contraseña = "toor";
$db_charset = "utf8";