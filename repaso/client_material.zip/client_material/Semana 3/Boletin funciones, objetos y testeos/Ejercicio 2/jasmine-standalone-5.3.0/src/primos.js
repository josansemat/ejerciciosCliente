function filtrarPrimosMayoresOnce(array) {
    let primos = array.filter(num => num > 11 && esPrimo(num));
    primos.sort((a, b) => a - b);
    return primos;
}

function esPrimo(num) {
    if(num < 2) {
        return false;
    }
    for(let i = 2; i <= Math.sqrt(num); i++) {
        if(num%i == 0) {
            return false;
        }
    }
    return true;
}