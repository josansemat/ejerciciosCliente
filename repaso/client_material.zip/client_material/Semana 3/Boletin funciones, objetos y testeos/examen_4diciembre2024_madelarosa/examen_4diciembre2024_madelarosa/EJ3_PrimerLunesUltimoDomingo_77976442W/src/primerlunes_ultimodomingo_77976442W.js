const ERROR_MES = "Mes incorrecto";

function primerLunesUltimoDomingo(año, mes) {
  if (mes < 0 || mes > 11) {
    return ERROR_MES;
  }

  // Obtener primer día del mes
  let fechaInicio = new Date(año, mes, 1);

  // Buscar el primer lunes del mes
  let primerLunes = new Date(fechaInicio);
  while (primerLunes.getDay() !== 1) {
    primerLunes.setDate(primerLunes.getDate() + 1);
  }

  // Obtener último día del mes
  let fechaFin = new Date(año, mes + 1, 0);

  // Buscar el último domingo del mes
  let ultimoDomingo = new Date(fechaFin);
  while (ultimoDomingo.getDay() !== 0) {
    ultimoDomingo.setDate(ultimoDomingo.getDate() - 1);
  }

  return {
    primerLunes: primerLunes.getDate(),
    ultimoDomingo: ultimoDomingo.getDate()
  };
}
