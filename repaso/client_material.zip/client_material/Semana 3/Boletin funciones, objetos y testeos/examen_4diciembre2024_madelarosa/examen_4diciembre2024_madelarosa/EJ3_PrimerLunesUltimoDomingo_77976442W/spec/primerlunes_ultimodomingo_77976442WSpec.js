describe("primerLunesUltimoDomingo", function () {
  const datos = [
    { entrada: { año: 1942, mes: 3 }, primerLunes: 6, ultimoDomingo: 26 },
    { entrada: { año: 1946, mes: 12 }, primerLunes: 2, ultimoDomingo: 29 },
    { entrada: { año: 1973, mes: 4 }, primerLunes: 7, ultimoDomingo: 27 },
    { entrada: { año: 1975, mes: 2 }, primerLunes: 3, ultimoDomingo: 30 },
    { entrada: { año: 1996, mes: 11 }, primerLunes: 2, ultimoDomingo: 29 },
  ];

  for (let i = 0; i < datos.length; i++) {
    const { año, mes } = datos[i].entrada;
    const esperado = { primerLunes: datos[i].primerLunes, ultimoDomingo: datos[i].ultimoDomingo };

    it(`Dado año ${año}, mes ${mes}, devuelve primer lunes ${esperado.primerLunes} y último domingo ${esperado.ultimoDomingo}`, function () {
      expect(primerLunesUltimoDomingo(año, mes)).toEqual(esperado);
    });
  }
});
