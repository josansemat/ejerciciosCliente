const lados = [6.8, 7.1, 7.4];
const alturas = [9, 9.4, 9.8];
const resultados = [177.083, 193.092, 209.793];

describe('triangulo', () => {
    for(let i = 0; i < lados.length; i++){
        it('el area del triangulo con lado ' + lados[i] + ' y altura ' + alturas[i] + ' debe dar ' + resultados[i], () => {
            expect(piramide(lados[i], alturas[i])).toBeCloseTo(resultados[i], 3);
        });
    }
});