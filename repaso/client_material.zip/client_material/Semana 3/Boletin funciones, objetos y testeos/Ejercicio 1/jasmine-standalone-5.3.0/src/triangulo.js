function piramide(l, h) {
    let area = l*(l + Math.sqrt(4*Math.pow(h, 2) + Math.pow(l, 2)));
    return Number(area.toFixed(3));
}