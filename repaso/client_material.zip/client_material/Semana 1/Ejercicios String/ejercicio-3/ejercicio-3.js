let nombre = "Luis Mejías Ruiz";
nombre = nombre.toUpperCase();
console.log(nombre);
nombre = nombre.toLowerCase();
console.log(nombre);