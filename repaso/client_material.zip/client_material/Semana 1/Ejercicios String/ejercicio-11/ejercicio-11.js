let str = "En un lugar de la Mancha de cuyo nombre no quiero acordarme";
let sub = str.substring(6, 11);
console.log(str);
console.log(sub);