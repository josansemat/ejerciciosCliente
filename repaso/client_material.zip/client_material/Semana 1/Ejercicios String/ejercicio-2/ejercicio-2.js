let nombre = "Luis Mejías Ruiz";

for (let i = 0; i < nombre.length; i++) {
    console.log(nombre.charAt(i));
}