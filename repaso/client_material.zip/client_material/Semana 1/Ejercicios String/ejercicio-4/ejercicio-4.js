let cadena = "En un lugar de la Mancha de cuyo nombre no quiero acordarme";

let long = cadena.length;

console.log(long);

let pos = cadena.indexOf("Mancha");
console.log(pos);
let pos2 = cadena.indexOf("Quijote");
console.log(pos2);
let last = cadena.lastIndexOf("de");
console.log(last);