let cadena = "En un lugar de la Mancha de cuyo nombre no quiero acordarme";
console.log(cadena.startsWith("En"));
console.log(cadena.startsWith("lugar"));