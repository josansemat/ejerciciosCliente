let cadena = "En un lugar de la Mancha de cuyo nombre no quiero acordarme";
console.log(cadena.replace("Mancha", "Andalucía"));