let str = " Javier Soldado ";
console.log(str);
str = str.trim();
console.log(str);