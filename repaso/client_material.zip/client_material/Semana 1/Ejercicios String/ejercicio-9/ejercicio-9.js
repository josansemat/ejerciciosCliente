let frutas = "Cebollas;Patatas;Pimientos;Tomates";
frutas = frutas.split(";");
console.log(frutas);