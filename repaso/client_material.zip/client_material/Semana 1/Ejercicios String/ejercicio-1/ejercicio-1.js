let nombre = "Luis Mejías Ruiz";

console.log(nombre.length);