let cadena = "En un lugar de la Mancha de cuyo nombre no quiero acordarme";
let sub = cadena.substring(6, 11);
console.log(sub);