let cadena = "En un lugar de la Mancha de cuyo nombre no quiero acordarme";
console.log(cadena.includes("cuyo"));
console.log(cadena.includes("lugar", 12));