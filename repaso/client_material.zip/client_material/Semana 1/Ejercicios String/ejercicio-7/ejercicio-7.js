let cadena = "En un lugar de la Mancha de cuyo nombre no quiero acordarme";
console.log(cadena.endsWith("acordarme"));
console.log(cadena.endsWith("hidalgo"));