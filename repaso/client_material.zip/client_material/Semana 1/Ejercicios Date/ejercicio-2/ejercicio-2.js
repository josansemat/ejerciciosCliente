let date = new Date(2004, 6, 16);
console.log(date); // Fecha completa