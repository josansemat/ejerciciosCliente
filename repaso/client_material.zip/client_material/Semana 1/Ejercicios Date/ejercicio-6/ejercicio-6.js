let milisegundos = 1089936000000;
let fechaNacimiento = new Date(milisegundos);
console.log(fechaNacimiento);