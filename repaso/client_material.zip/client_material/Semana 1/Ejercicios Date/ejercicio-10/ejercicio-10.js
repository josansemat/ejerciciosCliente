let date = new Date(2021, 0, 35);
console.log(date);

// Lo que ocurre es que ajusta la fecha automaticamente al siguiente mes.
// En este caso, 35 días después de enero (que tiene 31 días) es el 4 de marzo.
// Por lo tanto, la fecha resultante es 4/3/2021.