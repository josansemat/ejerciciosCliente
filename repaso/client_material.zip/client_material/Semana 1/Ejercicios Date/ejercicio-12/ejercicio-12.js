let date = new Date("2004-07-16");
console.log(date);