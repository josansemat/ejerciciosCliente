console.log(Date.now());
console.log(new Date(Date.now()));