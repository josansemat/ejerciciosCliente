let arr = [2, 7, 22, 3, 30, 17];

let impares = arr.filter((element) => element % 2 !== 0);

console.log(impares);