let arr = [2, 12, 22, 30, 36];

let pares = arr.every((elemento) => elemento % 2 === 0);

console.log(pares); // Devuelve true si todos son pares, false si alguno no lo es