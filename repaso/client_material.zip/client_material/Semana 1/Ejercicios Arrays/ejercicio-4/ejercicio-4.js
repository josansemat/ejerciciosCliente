let arr = ["Huelva", "Sevilla", "Córdoba"];
arr.unshift("Cádiz");
arr.shift();