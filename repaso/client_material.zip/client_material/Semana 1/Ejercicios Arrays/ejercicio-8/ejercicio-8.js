let arr = ["Plátanos", "Naranjas", "Pomelos", "Fresas"];

console.log(arr.slice(2, 3)); //No se elimina del array
console.log(arr);