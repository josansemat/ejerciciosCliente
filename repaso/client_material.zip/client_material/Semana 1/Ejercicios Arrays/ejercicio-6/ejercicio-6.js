let arr = ["Huelva", "Sevilla", "Córdoba", "Jaén", "Almería", "Granada", "Málaga", "Cádiz"];

arr.sort((a, b) => a.localeCompare(b));

console.log(arr);
console.log(arr.reverse());