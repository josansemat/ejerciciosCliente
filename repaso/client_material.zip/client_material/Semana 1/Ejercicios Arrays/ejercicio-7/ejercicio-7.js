let arr = ["Plátanos", "Naranjas", "Pomelos", "Fresas"];

arr.splice(1, 1);

console.log(arr); 

arr.splice(1, 0, "Limones");

console.log(arr);