let arr1 = ["Plátanos", "Naranjas", "Pomelos"];
let arr2 = ["Cebollas", "Pepinos", "Pimientos"];
let arr3 = arr1.concat(arr2);
console.log(arr3); // ["Plátanos", "Naranjas", "Pomelos", "Cebollas", "Pepinos", "Pimientos"]