let arr = ["Plátanos", "Naranjas", "Pomelos", "Fresas"];

console.log(arr.indexOf("Naranjas"));
console.log(arr.indexOf("Sandia")); //-1