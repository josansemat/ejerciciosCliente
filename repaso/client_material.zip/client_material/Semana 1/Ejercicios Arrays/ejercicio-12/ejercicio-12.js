let arr =  ['Plátanos', 'Naranjas', 'Pomelos', 'Fresas'];

console.log(arr.includes('Naranjas')); // true
console.log(arr.includes('Peras')); // false