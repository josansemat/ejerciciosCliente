let arr = ['Plátanos', 'Naranjas', 'Pomelos', 'Plátanos', 'Fresas'];

let lastPosition = arr.lastIndexOf('Plátanos');

console.log(lastPosition);