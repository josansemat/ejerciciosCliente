let arr = ["Huelva", "Sevilla", "Córdoba"];
delete arr[1]; 
console.log(arr[1]); // undefined