let arr = [2, 12, 7, 22, 3, 30, 17];

let impar = arr.find((element) => element % 2 !== 0);

console.log(impar); 