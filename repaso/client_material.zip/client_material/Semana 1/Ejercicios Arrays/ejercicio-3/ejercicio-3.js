let arr = ["Huelva", "Sevilla", "Córdoba"];
arr.push("Jaén", "Granada");
arr.pop();