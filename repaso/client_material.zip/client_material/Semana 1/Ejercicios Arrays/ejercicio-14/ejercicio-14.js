let arr = [2, 9, 7, 5.4, 8];

let cuadrado = arr.map((element) => element ** 2);

console.log(cuadrado);