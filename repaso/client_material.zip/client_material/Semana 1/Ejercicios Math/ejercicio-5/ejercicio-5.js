console.log(Math.log10(12.5));
console.log(Math.log(15.7));