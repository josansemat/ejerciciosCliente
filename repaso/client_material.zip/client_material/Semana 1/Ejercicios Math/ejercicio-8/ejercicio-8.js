console.log(Math.ceil(2.7));
console.log(Math.ceil(-2.7));
console.log(Math.ceil(12.5));
console.log(Math.ceil(-0.6));
console.log(Math.ceil(0.6));