console.log(Math.round(Math.PI * 1000) / 1000);
console.log(Math.round(Math.PI * 10000) / 10000);
console.log(Math.round(Math.PI * 100000) / 100000);