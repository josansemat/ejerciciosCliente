console.log(Math.min(-8, 7));
console.log(Math.min(12, 5));
console.log(Math.min(-12, 5));