// function randomEntero(min, max) {
//     return Math.floor(Math.random() * (max - min + 1)) + min;
// }

console.log(Math.floor(Math.floor(Math.random() * (8 - 6 + 1)) + 6));