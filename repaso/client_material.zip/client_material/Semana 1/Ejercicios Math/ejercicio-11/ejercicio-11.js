console.log(Math.max(-8, 7));
console.log(Math.max(12, 5));
console.log(Math.max(-12, 5));