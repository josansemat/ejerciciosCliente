console.log(Math.round(2.7));
console.log(Math.round(-2.7));
console.log(Math.round(12.5));
console.log(Math.round(-0.6));
console.log(Math.round(0.6));