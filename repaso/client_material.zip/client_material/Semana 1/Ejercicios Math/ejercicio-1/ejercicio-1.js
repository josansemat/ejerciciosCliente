console.log(Math.abs(3));
console.log(Math.abs(-5));
console.log(Math.abs(8));
console.log(Math.abs(-3.5));
console.log(Math.abs(12.2));