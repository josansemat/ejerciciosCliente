console.log(Math.floor(2.7));
console.log(Math.floor(-2.7));
console.log(Math.floor(12.5));
console.log(Math.floor(-0.6));
console.log(Math.floor(0.6));