function validarCorreo(string) {
    let regex = /^([0-9a-zA-Z.-_]+)@([0-9a-zA-z_-]+)(\.[a-zA-Z]{2,4})$/;
    if(regex.test(string)==true){
        console.log("valido");
    }else{
        console.log("tonto o q");
    }
}

let correoBueno = "de323423smr@gmail.com";
let correoMalo= "dawdawdawdawdawawdawawdad";

validarCorreo(correoBueno);
validarCorreo(correoMalo);